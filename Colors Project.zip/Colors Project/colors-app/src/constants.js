export const DRAWER_WIDTH = 400;
